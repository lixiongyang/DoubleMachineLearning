# Y=audit quality
# D=big4
# X=controls variables

rm(list=ls())
srep=10   #simulation replications

est1 <- matrix(rep(NA, 6 * srep), ncol = 6)  # regression on subsamples
est2 <- matrix(rep(NA, 6 * srep), ncol = 6)  # combine and regression
colnames(est1) <-c("boost","bagging", "randomforest", "net", "ensemble_lm", "ensemble_rf")
colnames(est2) <-c("boost","bagging", "randomforest", "net", "ensemble_lm", "ensemble_rf")

for(i in 1:srep){
  
  
  #generate simulated data
  n=1000    #sample size
  u=rnorm(n)
  v=rnorm(n)
  x1=rnorm(n)
  x2=rnorm(n)
  x3=x1*x2
  
  dx = x1+x2+x3
  mx=1/(1+exp(-dx))
  fx=-6+12*x1+6*x2+2*x3
  
  d=rbinom(n,1,prob=mx)
  y <- 1*d+fx+u
  x=cbind.data.frame(x1,x2,x3)
  data=data.frame(y,x,d)
  
  x="x1+x2+x3"
  sed <- 123456  # default=123
  
  setwd("E:\\R-econometrics\\myDML")
  
  ###############################################
  # 2-fold validation
  source("dml_boost.R")
  dml_boost <- dml_boost(data=data,y,x,d,sed=sed)
  est1[i,1] <- dml_boost$theta1
  est2[i,1] <- dml_boost$theta2
  ################################################
  #4-fold validation
  #source("dml_boost4.R")  
  #dml_boost <- dml_boost4(data=data,y,x,d,sed=sed,k=4)
  
  
  ################################################
  #4-fold valudation
  #4-fold不匹配处理变量平衡性
  #source("dml_boost4old.R")
  #dml_boost <- dml_boost4(data=data,y,x,d,sed=sed,k=4)
  
  source("dml_bagging.R")
  dml_bagging <- dml_bagging(data=data,y,x,d,sed=sed)
  est1[i,2] <- dml_bagging$theta1
  est2[i,2] <- dml_bagging$theta2
  
  source("dml_rf.R")
  dml_rf <- dml_rf(data=data,y,x,d,sed=sed)
  est1[i,3] <- dml_rf$theta1
  est2[i,3] <- dml_rf$theta2
  
  source("dml_nn.R")
  dml_nn <- dml_nn(data=data,y,x,d,sed=sed)
  est1[i,4] <- dml_nn$theta1
  est2[i,4] <- dml_nn$theta2
  
  source("dml_ensemble.R")
  dml_ensemble <- dml_ensemble(data=data,y,x,d,sed=sed)
  est1[i,5] <- dml_ensemble$theta1
  est2[i,5] <- dml_ensemble$theta2
  
  
  source("ensemble_rf.R")
  ensemble_rf <- ensemble_rf(data=data,y,x,d,sed=sed)
  est1[i,6] <- ensemble_rf$theta1
  est2[i,6] <- ensemble_rf$theta2
  
}

mi1=colMeans(est1)
sd1=cbind(sd(est1[,1]),sd(est1[,2]),sd(est1[,3]),sd(est1[,4]),sd(est1[,5]), sd(est1[,6]))
print(list(mi1,sd1))


mi2=colMeans(est2)
sd2=cbind(sd(est2[,1]),sd(est2[,2]),sd(est2[,3]),sd(est2[,4]),sd(est2[,5]), sd(est2[,6]))
print(list(mi2,sd2))
