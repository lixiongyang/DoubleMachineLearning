dml_boost.R

This function computes the estimate of treatment effect
using double machine learning proposed by Chernozhukov et al. (2018, Econometrics Journal)