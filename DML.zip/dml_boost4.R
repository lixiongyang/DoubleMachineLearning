


dml_boost4 <- function(data,y,x,d,sed=123,k=4) {
  
  #split the sample into two parts
  library(caret)
  set.seed(sed)
  
  trainindex1=createDataPartition(d,p=0.25,list=F)
  d1=d[-trainindex1]
  trainindex2=createDataPartition(d1,p=0.33,list=F)
  d2=d1[-trainindex2]
  trainindex3=createDataPartition(d2,p=0.5,list=F)
  d3=d2[-trainindex3]
  trainindex4=createDataPartition(d3,p=1,list=F)

 
  train1=data[-trainindex1,]
  train2=data[-trainindex2,]
  train3=data[-trainindex3,]
  train4=data[-trainindex4,]
  
  test1=data[trainindex1,]
  test2=data[trainindex2,]
  test3=data[trainindex3,]
  test4=data[trainindex4,]
  
  y1=y[-trainindex1]
  y2=y[-trainindex2]
  y3=y[-trainindex3]
  y4=y[-trainindex4]
  
  d1=d[-trainindex1]
  d2=d[-trainindex2]
  d3=d[-trainindex3]
  d4=d[-trainindex4]
  
  
  formula.1 <- as.formula(paste("y1~",x))
  formula.2 <- as.formula(paste("d1~",x))
  
  formula.3 <- as.formula(paste("y2~",x))
  formula.4 <- as.formula(paste("d2~",x))
  
  formula.5 <- as.formula(paste("y3~",x))
  formula.6 <- as.formula(paste("d3~",x))
  
  formula.7 <- as.formula(paste("y4~",x))
  formula.8 <- as.formula(paste("d4~",x))
  
  #########################################################
  # Method 3: boosting
  library(gbm)
  set.seed(sed)
  #step 1
  boost.aq=gbm(formula.1,data=train1,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.aq)
  yhat.aq3=predict(boost.aq,newdata=test1,n.trees=100)
  ylhat1=y[trainindex1]-yhat.aq3
  #step2
  boost.aq=gbm(formula.3,data=train2,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.aq)
  yhat.aq3=predict(boost.aq,newdata=test2,n.trees=100)
  ylhat2=y[trainindex2]-yhat.aq3
  #step 3
  boost.aq=gbm(formula.5,data=train3,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.aq)
  yhat.aq3=predict(boost.aq,newdata=test3,n.trees=100)
  ylhat3=y[trainindex3]-yhat.aq3
  #step 4
  boost.aq=gbm(formula.7,data=train4,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.aq)
  yhat.aq3=predict(boost.aq,newdata=test4,n.trees=100)
  ylhat4=y[trainindex4]-yhat.aq3
  
  
  
  #E(d|y)
  #step 5
  boost.d=gbm(formula.2,data=train1,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.d)
  yhat.d3=predict(boost.d,newdata=test1,n.trees=100)
  vhat1=d[trainindex1]-yhat.d3
  #step 6
  boost.d=gbm(formula.4,data=train2,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.d)
  yhat.d3=predict(boost.d,newdata=test2,n.trees=100)
  vhat2=d[trainindex2]-yhat.d3
  #step 7
  boost.d=gbm(formula.6,data=train3,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.d)
  yhat.d3=predict(boost.d,newdata=test3,n.trees=100)
  vhat3=d[trainindex3]-yhat.d3
  
  #step 8
  boost.d=gbm(formula.8,data=train4,distribution="gaussian",n.trees=100,interaction.depth=4,shrinkage=0.1)
  summary(boost.d)
  yhat.d3=predict(boost.d,newdata=test4,n.trees=100)
  vhat4=d[trainindex4]-yhat.d3
  
  
  #step9: reg ylhat vhat
  lm.fit1=lm(ylhat1~vhat1)
  summary(lm.fit1)
  
  lm.fit2=lm(ylhat2~vhat2)
  summary(lm.fit2)
  
  lm.fit3=lm(ylhat3~vhat3)
  summary(lm.fit3)
  
  lm.fit4=lm(ylhat4~vhat4)
  summary(lm.fit4)
  
 # DML2: combine and reg
  dim1=length(ylhat1)
  dim2=length(ylhat2)
  dim3=length(ylhat3)
  dim4=length(ylhat4)
  dim=dim1+dim2+dim3+dim4
  dim5=dim1+1
  yhat=rep(NA,dim)
  yhat[1:dim1]=ylhat1
  yhat[(dim1+1):(dim1+dim2)]=ylhat2
  yhat[(dim1+dim2+1):(dim1+dim2+dim3)]=ylhat3
  yhat[(dim1+dim2+dim3+1):(dim1+dim2+dim3+dim4)]=ylhat3
  
  vhat=rep(NA,dim)
  vhat[1:dim1]=vhat1
  vhat[(dim1+1):(dim1+dim2)]=vhat2
  vhat[(dim1+dim2+1):(dim1+dim2+dim3)]=vhat3
  vhat[(dim1+dim2+dim3+1):(dim1+dim2+dim3+dim4)]=vhat3
  
  lm.all=lm(yhat~vhat)
  
  # compute robust standard error
  
  #install.packages("lmtest")
  #install.packages("sandwich")
  library(lmtest)
  library(sandwich)
  est1 = coeftest(lm.fit1, vcov = vcovHC, type = "HC0")
  est2 = coeftest(lm.fit2, vcov = vcovHC, type = "HC0")
  est3 = coeftest(lm.fit1, vcov = vcovHC, type = "HC0")
  est4 = coeftest(lm.fit2, vcov = vcovHC, type = "HC0")
  
  b1 = est1[2,1]
  b2 = est2[2,1]
  b3 = est3[2,1]
  b4 = est4[2,1]
  be = (b1+b2+b3+b4)/4
  
  se1 = est1[2,2]
  se2 = est2[2,2]
  se3 = est3[2,2]
  se4 = est4[2,2]
  sig2 =(se1^2+se2^2+se3^2+se4^2 +(b1-be)^2+(b2-be)^2+(b3-be)^2+(b4-be)^2)/4
  se =sqrt(sig2)
  t =be/se
 
  # combined reg
  estall = coeftest(lm.all, vcov = vcovHC, type = "HC0")
  beAll=estall[2,1]
  seAll=estall[2,2]
  tAll=beAll/seAll 
  
  # ouput the estimation results
  cat("-----------------------------------------------------------","\n")
  cat("Double machine learning 1 (boosting, 4-folds):","\n")
  cat("Estimate, s.e., t-statistic, p.value, 95%lower, 95%upper","\n")
  print(cbind(theta=be,se.robust=se,t.value=t,pvalue=round(2*(1-pnorm(abs(be/se))),5),
              be-1.96*se,be+1.96*se),digits=4)
  
  cat("t-statistic critial values: 90%=1.65, 95%=1.96, 99%=2.58","\n")
  cat("-----------------------------------------------------------","\n")
  
  
  cat("-----------------------------------------------------------","\n")
  cat("Double machine learning 2 (boosting, 2-folds):","\n")
  cat("Estimate, s.e., t-statistic, p.value, 95%lower, 95%upper","\n")
  print(cbind(theta=beAll,se.robust=seAll,t.value=tAll,pvalue=round(2*(1-pnorm(abs(beAll/seAll))),5),
              beAll-1.96*seAll,beAll+1.96*seAll),digits=4)
  
  cat("t-statistic critial values: 90%=1.65, 95%=1.96, 99%=2.58","\n")
  cat("-----------------------------------------------------------","\n")
  
}