dml_ensemble <- function(data,y,x,d,sed=123) {
  #split the sample into two parts
  set.seed(sed)
  library(caret)
  trainindex=createDataPartition(d,p=0.5,list=F)
  data1=data[trainindex,]
  data2=data[-trainindex,]
  y1=y[trainindex]
  y2=y[-trainindex]
  d1=d[trainindex]
  d2=d[-trainindex]

  formula.1 <- as.formula(paste("y1~",x))
  formula.2 <- as.formula(paste("d1~",x))
  
  formula.3 <- as.formula(paste("y2~",x))
  formula.4 <- as.formula(paste("d2~",x))
  mtry = ncol(data)-2
  ns <- ncol(data)-2
  #########################################################
  # method 5: ensemble learning
  set.seed(sed)
  #########################
  #step 1: E(Y|X) leanrning in sample 1; residuals in sample 2
  library(randomForest)
 
  #bagging
  bag.aq=randomForest( formula.1,data=data1,mtry=mtry,importance=TRUE)
  yhat.aq = predict(bag.aq, newdata = data1)
  
  #randomForest
  rf.aq=randomForest( formula.1,data=data1,ntree=25,importance=TRUE)
  yhat.aq2 = predict(rf.aq, newdata = data1)
  
  # boosting
  library(gbm)

  boost.aq=gbm( formula.1,data=data1,distribution="gaussian",
                n.trees=100,interaction.depth=4,shrinkage=0.1)
  yhat.aq3=predict(boost.aq,newdata=data1,n.trees=100)
  
  #nuetral networks
  library(nnet)
  #net.aq <- neuralnet( formula.1, data = data1,  hidden = 1, linear.output = FALSE)
  net.aq <- nnet(formula.1,data = data1,maxit=300,size=ns,linout=T)
  yhat.aq4=predict(net.aq,newdata=data1)
  #all train
  all.train=data.frame(yhat.aq,yhat.aq2,yhat.aq3,yhat.aq4)
  all.train=data.frame(cbind(all.train, y1))
  
  ensemble.model=lm( y1~.,data=all.train)
  
  #in test 
  yhat.aq = predict(bag.aq, newdata = data2)
  yhat.aq2 = predict(rf.aq, newdata = data2)
  yhat.aq3=predict(boost.aq,newdata=data2,n.trees=100)
  yhat.aq4=predict(net.aq,newdata=data2)
  all.test=data.frame(yhat.aq,yhat.aq2,yhat.aq3,yhat.aq4)
  all.test=data.frame(cbind(all.test, y2))
  
  fit1 = predict(ensemble.model, all.test)
  ylhat51=y2-fit1
  
  ##########################
  #step 2: E(D|X) leanrning in sample 1; residuals in sample 2
  
  #bagging
  bag.d=randomForest(formula.2,data=data1,mtry=mtry,importance=TRUE)
  yhat.d = predict(bag.d, newdata = data1)
  
  #randomForest
  rf.d=randomForest(formula.2,data=data1,ntree=25,importance=TRUE)
  yhat.d2 = predict(rf.d, newdata = data1)
  
  # boosting
  boost.d=gbm(formula.2,data=data1,distribution="gaussian",
               n.trees=100,interaction.depth=4,shrinkage=0.1)
  yhat.d3=predict(boost.d,newdata=data1,n.trees=100)
  
  #nuetral networks
  #net.d <- neuralnet(formula.2, data = data1, hidden = 1, linear.output = FALSE)
  net.d <- nnet(formula.2,data = data1,maxit=300,size=ns,linout=T)
  yhat.d4=predict(net.d,newdata=data1)
  #all train
  all.train=data.frame(yhat.d,yhat.d2,yhat.d3,yhat.d4)
  all.train=data.frame(cbind(all.train,d1))
  

  ensemble.model=lm(d1~.,data=all.train)
  #in test 
  yhat.d = predict(bag.d, newdata = data2)
  yhat.d2 = predict(rf.d, newdata = data2)
  yhat.d3=predict(boost.d,newdata=data2,n.trees=100)
  yhat.d4=predict(net.d,newdata=data2)
  all.test=data.frame(yhat.d,yhat.d2,yhat.d3,yhat.d4)
  all.test=data.frame(cbind(all.test,d2))
  
  fit2 = predict(ensemble.model, all.test)
  vhat51=d2-fit2
  
  ###########################
  #step 3: E(Y|X) leanrning in sample 2; residuals in sample 1
  
  #bagging
  bag.aq=randomForest( formula.3,data=data2,mtry=mtry,importance=TRUE)
  yhat.aq = predict(bag.aq, newdata = data2)
  
  #randomForest
  rf.aq=randomForest( formula.3,data=data2,ntree=25,importance=TRUE)
  yhat.aq2 = predict(rf.aq, newdata = data2)
  
  # boosting
  boost.aq=gbm( formula.3,data=data2,distribution="gaussian",
                n.trees=100,interaction.depth=4,shrinkage=0.1)
  yhat.aq3=predict(boost.aq,newdata=data2,n.trees=100)
  
  #nuetral networks
  #net.aq <- neuralnet( formula.3, data = data2, hidden = 1, linear.output = FALSE)
  net.aq <- nnet(formula.3,data = data2,maxit=300,size=ns,linout=T)
  yhat.aq4=predict(net.aq,newdata=data2)
  #all train
  all.train=data.frame(yhat.aq,yhat.aq2,yhat.aq3,yhat.aq4)
  all.train=data.frame(cbind(all.train,y2))
  #model
  ensemble.model=lm( y2~.,data=all.train)
  
  #in test 
  yhat.aq = predict(bag.aq, newdata = data1)
  yhat.aq2 = predict(rf.aq, newdata = data1)
  yhat.aq3=predict(boost.aq,newdata=data1,n.trees=100)
  yhat.aq4=predict(net.aq,newdata=data1)
  all.test=data.frame(yhat.aq,yhat.aq2,yhat.aq3,yhat.aq4)
  all.test=data.frame(cbind(all.test, y1))
  
  fit3 = predict(ensemble.model, all.test)
  ylhat52=y1-fit3
  ##############################
  #step 4: E(D|X) leanrning in sample 2; residuals in sample 1
  
  #bagging
  bag.d=randomForest(formula.4,data=data2,mtry=mtry,importance=TRUE)
  yhat.d = predict(bag.d, newdata = data2)
  
  #randomForest
  rf.d=randomForest(formula.4,data=data2,ntree=25,importance=TRUE)
  yhat.d2 = predict(rf.d, newdata = data2)
  
  # boosting
  boost.d=gbm(formula.4,data=data2,distribution="gaussian",
               n.trees=100,interaction.depth=4,shrinkage=0.1)
  yhat.d3=predict(boost.d,newdata=data2,n.trees=100)
  
  #nuetral networks
  #net.d <- neuralnet(formula.4, data = data2, hidden = 1, linear.output = FALSE)
  net.d <- nnet(formula.4,data = data2,maxit=300,size=ns,linout=T)
  yhat.d4<-predict(net.d,newdata=data2)
  
  #all train
  all.train=data.frame(yhat.d,yhat.d2,yhat.d3,yhat.d4)
  all.train=data.frame(cbind(all.train,d2))
  
  ensemble.model=lm(d2~.,data=all.train)
  
  #in test 
  yhat.d = predict(bag.d, newdata = data1)
  yhat.d2 = predict(rf.d, newdata = data1)
  yhat.d3=predict(boost.d,newdata=data1,n.trees=100)
  yhat.d4=predict(net.d,newdata=data1)
  all.test=data.frame(yhat.d,yhat.d2,yhat.d3,yhat.d4)
  all.test=data.frame(cbind(all.test,d1))
  fit4 = predict(ensemble.model, all.test)
  vhat52=d1-fit4 
  
  #step5: reg ylhat vhat
  lm.fit1=lm(ylhat51~vhat51)
  summary(lm.fit1)
  
  lm.fit2=lm(ylhat52~vhat52)
  summary(lm.fit2)
  
  # DML2: combine and reg
  dim1=length(ylhat51)
  dim2=length(ylhat52)
  dim=dim1+dim2
  
  dim3=dim1+1
  yhat=rep(NA,dim)
  yhat[1:dim1]=ylhat51
  yhat[dim3:dim]=ylhat52
  
  vhat=rep(NA,dim)
  vhat[1:dim1]=vhat51
  vhat[dim3:dim]=vhat52
  
  lm.all=lm(yhat~vhat)
  # compute robust standard error
  
  #install.packages("lmtest")
  #install.packages("sandwich")
  library(lmtest)
  library(sandwich)
  est1 = coeftest(lm.fit1, vcov = vcovHC, type = "HC0")
  est2 = coeftest(lm.fit2, vcov = vcovHC, type = "HC0")
  
  b1 = est1[2,1]
  b2 = est2[2,1]
  be = (b1+b2)/2
  
  se1 = est1[2,2]
  se2 = est2[2,2]
  sig2 =(se1^2+se2^2 +(b1-be)^2+(b2-be)^2)/2
  se =sqrt(sig2)
  t =be/se
  
  
  
  # combined reg
  estall = coeftest(lm.all, vcov = vcovHC, type = "HC0")
  beAll=estall[2,1]
  seAll=estall[2,2]
  tAll=beAll/seAll
  
  
  # ouput the estimation results
  cat("-----------------------------------------------------------","\n")
  cat("Double machine learning 1 (ensemble learning , 2-folds):","\n")
  cat("Estimate, s.e., t-statistic, p.value, 95%lower, 95%upper","\n")
  print(cbind(theta=be,se.robust=se,t.value=t,pvalue=round(2*(1-pnorm(abs(be/se))),5),
              be-1.96*se,be+1.96*se),digits=4)
  
  cat("t-statistic critial values: 90%=1.65, 95%=1.96, 99%=2.58","\n")
  cat("-----------------------------------------------------------","\n")
  
  
  
  
  cat("-----------------------------------------------------------","\n")
  cat("Double machine learning 2 (ensemble learning, 2-folds):","\n")
  cat("Estimate, s.e., t-statistic, p.value, 95%lower, 95%upper","\n")
  print(cbind(theta=beAll,se.robust=seAll,t.value=tAll,pvalue=round(2*(1-pnorm(abs(beAll/seAll))),5),
              beAll-1.96*seAll,beAll+1.96*seAll),digits=4)
  
  cat("t-statistic critial values: 90%=1.65, 95%=1.96, 99%=2.58","\n")
  cat("-----------------------------------------------------------","\n")
return(list(theta1=be,se.robust1=se, theta2=beAll,se.robust2=seAll))
  
}

  